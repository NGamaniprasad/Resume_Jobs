from django.contrib.auth import login, authenticate
from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.http import Http404, HttpResponse


def navbar(request):
    return render(request, 'nav.html')


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'code.html')


from django.contrib.auth.hashers import make_password, check_password
from .models import User


def signup(request):
    if request.method == 'POST':
        username = request.POST['username']
        age = request.POST['age']
        phone_number = request.POST['phone_number']
        email = request.POST['email']
        password = make_password(request.POST['password'])

        user = User(username=username, age=age, phone_number=phone_number, email=email, password=password)
        user.save()

        return redirect('login')

    return render(request, 'signup.html')


def login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']

        try:
            user = User.objects.get(email=email)
            if check_password(password, user.password):
                return redirect('teams')
                # return HttpResponse("good")
            else:
                return redirect('invalid')
        except User.DoesNotExist:
            return  redirect('Notfound')

    return render(request, 'login.html')


from .models import Player

def invalid(request):
    return render(request,'Invalid.html')
def Notfound(request):
    return render(request,'Invalid1.html')
def search_player(request):
    query = request.GET.get('player_name', '')
    players = []

    if query:
        players = Player.objects.filter(name__icontains=query)

    return render(request, 'search.html', {'players': players, 'query': query})


def about(request):
    return render(request, 'about.html')


def contact(request):
    return render(request, 'code.html')


# Task_3

from django.core.mail import send_mail, BadHeaderError


def teams(request):
    return render(request, 'teams11.html')


# FINE

def info(request):
    template = "info.html"
    return render(request, template, {})


# -------------perfect
# ALLSET

from .models import Team, Match
from datetime import date


# Display Points Table
def points_table(request):
    """Display the current points table."""
    teams = Team.objects.all().order_by('-points', '-won')
    return render(request, 'points_table.html', {'teams': teams})


def select_teams(request):
    """Display the team selection form."""
    teams = Team.objects.all()
    if request.method == 'POST':
        team1_id = request.POST.get('team1')
        team2_id = request.POST.get('team2')
        winner_id = request.POST.get('winner')

        team1 = Team.objects.get(id=team1_id)
        team2 = Team.objects.get(id=team2_id)
        winner = Team.objects.get(id=winner_id)

        match = Match.objects.create(
            team1=team1,
            team2=team2,
            date=date.today(),
        )
        match.set_winner(winner)

        return redirect('points_table')

    return render(request, 'select_teams.html', {'teams': teams})


def condition(request):
    return render(request, 'terms.html')


# -----------------------------4

from .models import Batsman, MostWickets


def search_batsman(request):
    query = request.GET.get('query', '')
    batsmen = Batsman.objects.filter(name__icontains=query) if query else Batsman.objects.all()

    # Find the Orange Cap Winner (Highest Runs)
    orange_cap_winner = Batsman.objects.order_by('-total_runs').first()

    return render(request, 'data_search.html', {
        'batsmen': batsmen,
        'orange_cap_winner': orange_cap_winner,
    })


def search_bowler(request):
    query = request.GET.get('query', '')
    bowlers = MostWickets.objects.filter(name__icontains=query) if query else MostWickets.objects.all()

    # Find the Purple Cap Winner (Most Wickets)
    purple_cap_winner = MostWickets.objects.order_by('-wickets').first()

    return render(request, 'data_search.html', {
        'bowlers': bowlers,
        'purple_cap_winner': purple_cap_winner,
    })


def searhcricket(request):
    return render(request, 'data_search.html')


def Flex(request):
    return render(request, 'Flex.html')


# ---SET

from django.shortcuts import render, redirect, get_object_or_404
from .models import AuctionPlayer, Ipl_Teams
from .forms import AuctionPlayerForm


def add_player(request):
    if request.method == "POST":
        form = AuctionPlayerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_players')
    else:
        form = AuctionPlayerForm()
    return render(request, 'add.html', {'form': form})


def view_players(request):
    players = AuctionPlayer.objects.all()
    return render(request, 'view_players.html', {'players': players})


def update_player(request, player_id):
    player = get_object_or_404(AuctionPlayer, id=player_id)
    if request.method == "POST":
        form = AuctionPlayerForm(request.POST, instance=player)
        if form.is_valid():
            form.save()
            return redirect('view_players')
    else:
        form = AuctionPlayerForm(instance=player)
    return render(request, 'update.html', {'form': form})


def remove_player(request, player_id):
    player = get_object_or_404(AuctionPlayer, id=player_id)
    if request.method == "POST":
        player.delete()
        return redirect('view_players')
    return render(request, 'delete_performance.html', {'player': player})


def fixtures(request):
    return render(request, 'Fixtures.html')


# ---6

from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect

from django.core.mail import send_mail
from django.contrib import messages


def contact_view(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

        try:
            # Construct the email
            subject = f"Message from {name} via IPL Auction Tracker"
            full_message = f"Name: {name}\nEmail: {email}\n\nMessage:\n{message}"

            # Send email
            send_mail(
                subject=subject,
                message=full_message,
                from_email=email,
                recipient_list=['ngamaniprasad@gmail.com'],
                fail_silently=False,
            )

            messages.success(request, "Your message has been sent successfully. We'll get back to you soon!")

        except Exception as e:
            # Error
            messages.error(request, f"An error occurred while sending your message: {e}")

        return redirect('success')

    return render(request, 'code.html')  # Render the contact form for GET request


# --7
import csv
from io import StringIO

from .models import AuctionPlayer


def download_csv(request):
    players = AuctionPlayer.objects.all()
    # Create a response object with CSV content type
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="players.csv"'

    writer = csv.writer(response)
    writer.writerow(['Name', 'Age', 'Country', 'Base Price', 'Sold Price', 'Sold Team'])

    for player in players:
        writer.writerow(
            [player.name, player.age, player.country, player.base_price, player.sold_price, player.sold_team])

    return response


# ---------------------------------------------


# #------------------------------
from django.shortcuts import render, redirect
from .forms import ImageForm, VideoForm, FileForm
from .models import Video, Image, File


def upload_image(request):
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_images')  # Redirect to image view page
    else:
        form = ImageForm()
    return render(request, 'media/upload_image.html', {'form': form})


# View to upload videos
def upload_video(request):
    if request.method == 'POST':
        form = VideoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_videos')  # Redirect to video view page
    else:
        form = VideoForm()
    return render(request, 'media/upload_video.html', {'form': form})


def upload_file(request):
    if request.method == 'POST':
        form = FileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_files')  # Redirect to file view page
    else:
        form = FileForm()
    return render(request, 'media/upload_file.html', {'form': form})


# View to display images
def view_images(request):
    images = Image.objects.all()
    return render(request, 'media/images.html', {'images': images})


# View to display videos
def view_videos(request):
    videos = Video.objects.all()
    return render(request, 'media/videos.html', {'videos': videos})


# View to display files
def view_files(request):
    files = File.objects.all()
    return render(request, 'media/files.html', {'files': files})


def Media(request):
    return render(request, 'media/Media.html')


# 8

from django.views.decorators.http import require_POST
from .models import Video


@require_POST
def delete_video(request, video_id):
    video = get_object_or_404(Video, id=video_id)
    video.delete()
    return HttpResponse("<h2 style='color:red'>Your image deleted successfully!</h2>")


from django.views.decorators.http import require_POST
from .models import Image


@require_POST
def delete_image(request, image_id):
    image = get_object_or_404(Image, id=image_id)
    image.delete()
    return HttpResponse("<h1 style='color:red'>Your image deleted successfully!</h1>")


from django.views.decorators.http import require_POST
from .models import File


@require_POST
def delete_file(request, file_id):
    file = get_object_or_404(File, id=file_id)
    file.delete()
    return HttpResponse("<h1 style='color:red'>Your file deleted successfully!</h1>")
