document.addEventListener('DOMContentLoaded', () => {
    const signupForm = document.querySelector('form');
    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            const password = document.querySelector('#password');
            if (password.value.length < 8) {
                alert('Password must be at least 8 characters long.');
                e.preventDefault();  // Prevent form submission
            }
        });
    }
});
