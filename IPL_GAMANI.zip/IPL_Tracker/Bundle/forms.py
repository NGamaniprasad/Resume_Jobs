from django import forms
from .models import AuctionPlayer

class AuctionPlayerForm(forms.ModelForm):
    class Meta:
        model = AuctionPlayer
        fields = ['name', 'age', 'country', 'base_price', 'sold_price', 'sold_team']
