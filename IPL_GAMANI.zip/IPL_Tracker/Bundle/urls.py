from django.urls import path
from .import views

urlpatterns = [
    path('', views.navbar, name='navbar'),
    path('about/',views.about,name='about'),
    path('contact/', views.contact, name='contact'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('search/', views.search_player, name='search_player'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    path('contact_view',views.contact_view,name='contact_view'),
    path('success/', views.contact_view, name='success'),
    path('teams/',views.teams,name='teams'),

   # path('team/<int:team_id>/players/', views.view_players, name='view_players'),

    #path('player/<int:player_id>/', views.view_player_detail, name='view_player_detail'),

    #path('team/<int:team_id>/add_player/', views.add_player, name='add_player'),

    #path('player/<int:player_id>/update/', views.update_player, name='update_player'),

    #path('player/<int:player_id>/remove/', views.remove_player, name='remove_player'),
    path('info/',views.info,name='info'),

    # path('team/<int:team_id>/add/', views.add_player, name='add_player'),


   #  path('team_wise_players/',views.team_wise_players,name='team_wise_players'),
   # path('team/<int:team_id>/download_csv/', views.download_player_csv, name='download_player_csv'),
    #good
    path('points_table/', views.points_table, name='points_table'),
    path('select_teams/', views.select_teams, name='select_teams'),
    path('condition/', views.condition, name='condition'),
    #--4
    path('search/batsman/', views.search_batsman, name='search_batsman'),
    path('search_bowlerr/', views.search_bowler, name='search_bowler'),
    path('searhcricket/',views.searhcricket,name='searhcricket'),
    # path('auction_player_list/', views.auction_player_list, name='auction_player_list'),
    # path('add_player/', views.add_player, name='add_player'),
    # path('update/<int:pk>/', views.update_player, name='update_player'),
    # -SET
    # path('show_performance<int:team_id>/', views.show_performance, name='show_performance'),
    #
    # path('teams_list/', views.teams_list, name='teams_list'),
    # path('add_performance/', views.add_performance, name='add_performance'),
    # path('update_performance/<int:performance_id>/', views.update_performance, name='update_performance'),
    # path('view_performance/<int:performance_id>/', views.view_performance, name='view_performance'),
    # path('delete_performance/<int:performance_id>/', views.delete_performance, name='delete_performance'),
    path('add_player/', views.add_player, name='add_player'),
    path('view_players/', views.view_players, name='view_players'),
    path('update_player/<int:player_id>/', views.update_player, name='update_player'),
    path('remove_player/<int:player_id>/', views.remove_player, name='remove_player'),
    path('fixtures/',views.fixtures,name='fixtures')

]