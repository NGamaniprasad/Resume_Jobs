from django.urls import path
from . import views



urlpatterns = [
    path('', views.land, name='land'),
    path('index/',views.index,name='index'),

    path('register_user/', views.register_user, name='register_user'),
    path('view_users/', views.view_users, name='view_users'),
    path('update/<str:user_email>/', views.update_user, name='update_user'),
    path('delete/<str:user_email>/', views.delete_user, name='delete_user'),

    # media
    path('upload/image/', views.upload_image, name='upload_image'),
    path('upload/video/', views.upload_video, name='upload_video'),
    path('upload/file/', views.upload_file, name='upload_file'),

    path('images/', views.view_images, name='view_images'),
    path('videos/', views.view_videos, name='view_videos'),
    path('files/', views.view_files, name='view_files'),
    path('Media/', views.Media, name='Media'),
    # -8
    path('videos/delete/<int:video_id>/', views.delete_video, name='delete_video'),
    path('images/delete/<int:image_id>/', views.delete_image, name='delete_image'),
    path('files/delete/<int:file_id>/', views.delete_file, name='delete_file'),
]