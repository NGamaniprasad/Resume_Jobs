from django.db import models

class Registration(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    date_of_birth = models.DateField(null=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    registration_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
#------------------------------------------------

from django.db import models

# Model for Image
class Image(models.Model):
    title1 = models.CharField(max_length=100)
    image = models.ImageField(upload_to='images/')  # Store images in 'media/images/'

    def __str__(self):
        return self.title1

# Model for Video
class Video(models.Model):
    title2= models.CharField(max_length=100)
    video = models.FileField(upload_to='videos/')  # Store videos in 'media/videos/'

    def __str__(self):
        return self.title2

# Model for File
class File(models.Model):
    title3 = models.CharField(max_length=100)
    file = models.FileField(upload_to='files/')  # Store files in 'media/files/'

    def __str__(self):
        return self.title3a

class File1(models.Model):
    file = models.FileField(upload_to='files/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"File uploaded at {self.uploaded_at}"
