# from django.shortcuts import render
#
# from django.core.exceptions import ObjectDoesNotExist
#
# def index(request):
#     # Just render the main page, showing the search form
#     return render(request, 'index.html')
#
# #------------1
# from django.shortcuts import render
# from django.http import HttpResponse
#
# def set_cookie(request):
#     # Setting a cookie that will expire in 3600 seconds (1 hour)
#     response = HttpResponse("Cookie has been set!")
#     response.set_cookie('username', 'JohnDoe', max_age=3600)  # Cookie expires in 1 hour
#     response.set_cookie('email', '', max_age=3600)
#     return response
#
# def get_cookie(request):
#     # Retrieving the cookie
#     username = request.COOKIES.get('username', 'Guest')  # Default value 'Guest' if not found
#     email = request.COOKIES.get('email', 'Not provided')
#     return render(request, 'session.html', {'username': username, 'email': email})
#
# def delete_cookie(request):
#     # Deleting the cookie by setting its expiry date to the past
#     response = HttpResponse("Cookie has been deleted!")
#     response.delete_cookie('username')
#     response.delete_cookie('email')
#     return response
# #------2
# from django.core.paginator import Paginator
# from django.shortcuts import render
#
#
# def paginated_view(request):
#     # Simulating data (a list of dictionaries in this case)
#     data_list = [
#         {'name': f'Item {i}'} for i in range(1, 101)  # A list of 100 items
#     ]
#
#     # Create a Paginator instance
#     paginator = Paginator(data_list, 10)  # Show 10 items per page
#
#     # Get the current page number from the request
#     page_number = request.GET.get('page')
#
#     # Get the page object corresponding to the page number
#     page_obj = paginator.get_page(page_number)
#
#     # Pass the page_obj to the template
#     return render(request, 'session.html', {'page_obj': page_obj})
# #-----------------Working


from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Registration
from .forms import RegistrationForm

def register_user(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Registration successful!")
            return redirect('view_users')
    else:
        form = RegistrationForm()

    return render(request, 'register.html', {'form': form})

def view_users(request):
    registrations = Registration.objects.all()
    return render(request, 'view_users.html', {'registrations': registrations})


def update_user(request, user_email):
    # Fetch the user object based on email
    user = get_object_or_404(Registration, email=user_email)

    if request.method == "POST":
        form = RegistrationForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            messages.success(request, "User updated successfully!")
            return redirect('view_users')
    else:
        form = RegistrationForm(instance=user)

    return render(request, 'update_user.html', {'form': form, 'user': user})


def delete_user(request, user_email):
    # Fetch the user object based on email
    user = get_object_or_404(Registration, email=user_email)

    if request.method == "POST":
        user.delete()
        messages.success(request, "User deleted successfully!")
        return redirect('view_users')

    return render(request, 'delete_user.html', {'user': user})
def land(request):
    return render(request,'land.html')
#------------------------------
from django.shortcuts import render, redirect
from .forms import ImageForm,VideoForm,FileForm
from .models import Video,Image,File
def upload_image(request):
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_images')  # Redirect to image view page
    else:
        form = ImageForm()
    return render(request, 'upload_image.html', {'form': form})

# View to upload videos
def upload_video(request):
    if request.method == 'POST':
        form = VideoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_videos')  # Redirect to video view page
    else:
        form = VideoForm()
    return render(request, 'upload_video.html', {'form': form})


def upload_file(request):
    if request.method == 'POST':
        form = FileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('view_files')  # Redirect to file view page
    else:
        form = FileForm()
    return render(request, 'upload_file.html', {'form': form})

# View to display images
def view_images(request):
    images = Image.objects.all()
    return render(request, 'images.html', {'images': images})

# View to display videos
def view_videos(request):
    videos = Video.objects.all()
    return render(request, 'videos.html', {'videos': videos})

# View to display files
def view_files(request):
    files = File.objects.all()
    return render(request, 'files.html', {'files': files})
def Media(request):
    return render(request,'Media.html')
#8

from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from .models import Video



@require_POST
def delete_video(request, video_id):
    video = get_object_or_404(Video, id=video_id)
    video.delete()
    return HttpResponse("<h2 style='color:red'>Your image deleted successfully!</h2>")
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from .models import Image

from django.http import HttpResponse
@require_POST
def delete_image(request, image_id):
    image = get_object_or_404(Image, id=image_id)
    image.delete()
    return HttpResponse("<h1 style='color:red'>Your image deleted successfully!</h1>")

from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from .models import File



@require_POST
def delete_file(request, file_id):
    file = get_object_or_404(File, id=file_id)
    file.delete()
    return HttpResponse("<h1 style='color:red'>Your file deleted successfully!</h1>")

