from django.urls import path
from .import views

urlpatterns = [
    path('', views.navbar, name='navbar'),
    path('about/',views.about,name='about'),
    path('contact/', views.contact, name='contact'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('search/', views.search_player, name='search_player'),
    path('about/',views.about,name='about'),
    path('contact/',views.contact,name='contact'),
    path('contact_view',views.contact_view,name='contact_view'),
    path('success/', views.contact_view, name='success'),
    path('teams/',views.teams,name='teams'),
    path('info/',views.info,name='info'),
    #good
    path('points_table/', views.points_table, name='points_table'),
    path('select_teams/', views.select_teams, name='select_teams'),
    path('condition/', views.condition, name='condition'),
    #--4
    path('search/batsman/', views.search_batsman, name='search_batsman'),
    path('search_bowlerr/', views.search_bowler, name='search_bowler'),
    path('searhcricket/',views.searhcricket,name='searhcricket'),

    path('add_player/', views.add_player, name='add_player'),
    path('view_players/', views.view_players, name='view_players'),
    path('update_player/<int:player_id>/', views.update_player, name='update_player'),
    path('remove_player/<int:player_id>/', views.remove_player, name='remove_player'),
    path('fixtures/',views.fixtures,name='fixtures'),
    path('players/download/csv/', views.download_csv, name='download_csv'),

]