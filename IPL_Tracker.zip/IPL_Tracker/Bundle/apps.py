from django.apps import AppConfig


class BundleConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Bundle"
